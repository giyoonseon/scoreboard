import React from 'react';
import './App.css';
import {Header} from './components/Header';
import {Player} from './components/Player';
// ctrl + alt + o : 미사용 import 없애줌


//class컴포넌트로 변환
class App extends React.Component{
  state = {
    players :[
      {id:1, name: 'LDK',score:10},
      {id:2, name: 'PARK',score:20},
      {id:3, name: 'KIM',score:30},
      {id:4, name: 'LEE',score:40},
      {id:5, name: 'GI',score:100},
    ]
  }

  render() {
    return (
      <div className="scoreboard">
        <Header title="My Scoreboard" totalPlayers={11}></Header>
        {
          this.state.players.map((player) => (
            <Player name={player.name} key={player.id} id={player.id} score={player.score}  changeScore= {this.handleChangeScore} removePlayer={this.handleRemovePlayer}/>
          ))
        }
      </div>
    )
  }

  handleRemovePlayer =(id)=> {
    const players = this.state.players.filter(player => player.id !== id)
    console.log(players)
    this.setState(prevState => {
      const players = prevState.players.filter(player => player.id !== id)
      // Immutable 함수 = 새로운 배열을 리턴 = shallow comparison
      // 키와 변수가 같을 경우 한쪽을 생략: shorthand property
      return {players}
    })
  }

  handleChangeScore = (id, delta) => {
    console.log('handleChangeScore : ',id,' : ', delta);
    this.setState(prevState => {
      //새로운 배열을 리턴
      const players = [...prevState.players];
      //새로운 배열을 만들었기때문에 해당 배열을 건드려도 된다.
      players.forEach(player =>{
        if(player.id === id){
          player.score += delta
        }
      })
      return {players}
    })

  }
}
export default App;
